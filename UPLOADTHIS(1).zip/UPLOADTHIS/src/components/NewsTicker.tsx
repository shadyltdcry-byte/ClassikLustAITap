/**
 * NewsTicker.tsx
 * Last Edited: 2025-08-17 by Steven
 *
 *
 * 
 * Optional scrolling events/news
 *
 * Please leave a detailed description
 *      of each function you add
 */